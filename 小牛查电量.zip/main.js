const app = require("./scripts/app");
app.init();
