module.exports = {
  showSettings: showSettings
};

function showSettings() {
  $ui.push({
    props: {
      title: "设置"
    },
    events: {
      appeared: function () {
        getData();
      }
    },
    views: [
      {
        type: "view",
        props: {
          id: ""
        },
        layout: $layout.fill,
        views: [
          {
            type: "label",
            props: {
              id: "settings_snLabel",
              text: "SN码",
              align: $align.leading
            },
            layout: function (make, view) {
              make.size.equalTo($size(300, 32));
              make.centerX.equalTo(view.super);
            }
          },
          {
            type: "input",
            props: {
              id: "settings_sn",
              type: $kbType.search,
              darkKeyboard: true
            },
            layout: function (make, view) {
              make.size.equalTo($size(300, 50));
              make.centerX.equalTo(view.super);
              make.top.equalTo($("settings_snLabel").bottom);
            },
            events: {
              returned: function (sender) {
                sender.blur();
              }
            }
          },
          {
            type: "label",
            props: {
              id: "settings_tokenLabel",
              text: "Token",
              align: $align.leading
            },
            layout: function (make, view) {
              make.size.equalTo($size(300, 32));
              make.centerX.equalTo(view.super);
              make.top.equalTo($("settings_sn").bottom).offset(20);
            }
          },
          {
            type: "input",
            props: {
              id: "settings_token",
              type: $kbType.default,
              darkKeyboard: true
            },
            layout: function (make, view) {
              make.size.equalTo($size(300, 50));
              make.centerX.equalTo(view.super);
              make.top.equalTo($("settings_tokenLabel").bottom);
            },
            events: {
              returned: function (sender) {
                sender.blur();
              }
            }
          },
          {
            type: "button",
            props: {
              id: "settings_saveButton",
              title: "保存"
            },
            layout: function (make, view) {
              make.size.equalTo($size(300, 50));
              make.centerX.equalTo(view.super);
              make.top.equalTo($("settings_token").bottom).offset(50);
            },
            events: {
              tapped: function (sender) {
                saveData();
              }
            }
          }
        ]
      }
    ]
  });
}

function saveData() {
  let data = {
    sn: $("settings_sn").text,
    token: $("settings_token").text
  };

  $ui.loading(true);
  $cache.setAsync({
    key: "data",
    value: data,
    handler: function (object) {
      $ui.loading(false);
      $ui.pop();
      $ui.toast("保存成功!");
    }
  });
}

function getData() {
  $ui.toast("加载配置中...", 0.5);
  let cacheData = $cache.get("data");

  if (cacheData) {
    if (cacheData.sn) {
      $("settings_sn").text = cacheData.sn;
    }

    if (cacheData.token) {
      $("settings_token").text = cacheData.token;
    }
  }
}
