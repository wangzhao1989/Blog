const settings = require("./settings");
const cachePath = "assets/cache.json";
const config = $cache.get("data");

exports.init = async () => {
  if ($app.env == $env.widget) {
    const data = await fetch();
    renderWidget(data);
  } else {
    renderView();
  }
};

async function fetch() {
  const cache = JSON.parse($file.read(cachePath).string);

  const resp = await $http.get({
    url: `https://app-api.niu.com/v3/motor_data/index_info?sn=${config.sn}`,
    header: {
      Host: "app-api.niu.com",
      token: `${config.token}`
    }
  });

  if (resp == null || resp.response == null || resp.response.statusCode != 200) {
    return cache;
  }

  var data = resp.data;
  if (data["status"] == 0) {
    $file.write({
      data: $data({ string: JSON.stringify(data["data"]) }),
      path: cachePath
    });
  }

  return data["data"];
}

function renderWidget(data) {
  $widget.setTimeline({
    entries: [
      {
        date: new Date(),
        info: {}
      }
    ],
    policy: {
      atEnd: true
    },
    render: ctx => {
      return {
        type: "vstack",
        props: {
          alignment: $widget.horizontalAlignment.leading,
          spacing: 0,
          widgetURL: "jsbox://run?name=%E5%B0%8F%E7%89%9B%E6%9F%A5%E7%94%B5%E9%87%8F&location=local"
        },
        views: [
          {
            type: "hstack",
            props: {
              alignment: $widget.verticalAlignment.center,
              spacing: 8
            },
            views: [
              {
                type: "text",
                props: {
                  text: "🔋剩余电量",
                  align: $align.leading,
                  font: {
                    size: 13
                  }
                }
              },
              {
                type: "text",
                props: {
                  text: data["batteries"]["compartmentA"]["batteryCharging"] + "%",
                  font: {
                    size: 13
                  }
                }
              }
            ]
          },
          {
            type: "hstack",
            props: {
              alignment: $widget.verticalAlignment.center,
              spacing: 8
            },
            views: [
              {
                type: "text",
                props: {
                  text: "⚡️是否充电",
                  align: $align.leading,
                  font: {
                    size: 13
                  }
                }
              },
              {
                type: "text",
                props: {
                  id: "batteryLeft",
                  text: data["isCharging"] == 0 ? "否" : "是",
                  font: {
                    size: 13
                  }
                }
              }
            ]
          },
          {
            type: "hstack",
            props: {
              alignment: $widget.verticalAlignment.center,
              spacing: 8
            },
            views: [
              {
                type: "text",
                props: {
                  text: "🏍可行驶里程数",
                  align: $align.leading,
                  font: {
                    size: 13
                  }
                }
              },
              {
                type: "text",
                props: {
                  text: data["estimatedMileage"] + "KM",
                  font: {
                    size: 13
                  }
                }
              }
            ]
          },
          {
            type: "text",
            props: {
              text: "🕗最后更新时间",
              align: $align.leading,
              font: {
                size: 13
              }
            }
          },
          {
            type: "text",
            props: {
              text: timeTrans(data["time"]),
              font: {
                size: 13
              }
            }
          }
        ]
      };
    }
  });
}

function renderView() {
  $ui.render({
    props: {
      title: "小牛查电量",
      navButtons: [
        {
          image: $image("gearshape.fill"),
          handler: function () {
            settings.showSettings();
          }
        }
      ]
    },
    events: {
      appeared: function () {
        if (config) {
          getOnlineData();
        }
      }
    },
    views: [
      {
        type: "stack",
        layout: function (make, view) {
          make.edges.inset(30);
        },
        props: {
          axis: $stackViewAxis.vertical,
          spacing: 10,
          stack: {
            views: [
              {
                type: "stack",
                props: {
                  axis: $stackViewAxis.horizontal,
                  stack: {
                    views: [
                      {
                        type: "label",
                        props: {
                          text: "🔋剩余电量：",
                          align: $align.leading
                        }
                      },
                      {
                        type: "label",
                        props: {
                          id: "batteryLeft",
                          text: ""
                        }
                      }
                    ]
                  }
                }
              },
              {
                type: "stack",
                props: {
                  axis: $stackViewAxis.horizontal,
                  stack: {
                    views: [
                      {
                        type: "label",
                        props: {
                          text: "⚡️是否充电：",
                          align: $align.leading
                        }
                      },
                      {
                        type: "label",
                        props: {
                          id: "isCharging",
                          text: ""
                        }
                      }
                    ]
                  }
                }
              },
              {
                type: "stack",
                props: {
                  axis: $stackViewAxis.horizontal,
                  stack: {
                    views: [
                      {
                        type: "label",
                        props: {
                          text: "🏍可行驶里程数：",
                          align: $align.leading
                        }
                      },
                      {
                        type: "label",
                        props: {
                          id: "distanceLeft",
                          text: ""
                        }
                      }
                    ]
                  }
                }
              },
              {
                type: "stack",
                props: {
                  axis: $stackViewAxis.horizontal,
                  stack: {
                    views: [
                      {
                        type: "label",
                        props: {
                          text: "🕗最后更新时间：",
                          align: $align.leading
                        }
                      },
                      {
                        type: "label",
                        props: {
                          id: "updateTime",
                          text: ""
                        }
                      }
                    ]
                  }
                }
              },
              {
                type: "map",
                props: {
                  location: {}
                }
              },
              {
                type: "button",
                props: {
                  title: "刷新数据"
                },
                events: {
                  tapped: function (sender) {
                    getOnlineData();
                  }
                }
              }
            ]
          }
        }
      }
    ]
  });
}

function getOnlineData() {
  $http.get({
    url: `https://app-api.niu.com/v3/motor_data/index_info?sn=${config.sn}`,
    header: {
      Host: "app-api.niu.com",
      token: `${config.token}`
    },
    handler: function (resp) {
      var data = resp.data;
      if (data["status"] == 0) {
        $file.write({
          data: $data({ string: JSON.stringify(data["data"]) }),
          path: cachePath
        });

        $("batteryLeft").text = data["data"]["batteries"]["compartmentA"]["batteryCharging"] + "%";
        $("isCharging").text = data["data"]["isCharging"] == 0 ? "否" : "是";
        $("distanceLeft").text = data["data"]["estimatedMileage"] + "KM";
        $("updateTime").text = timeTrans(data["data"]["time"]);
        $("map").location = {
          lat: data["data"]["postion"]["lat"],
          lng: data["data"]["postion"]["lng"]
        };
      }
    }
  });
}

function timeTrans(time) {
  //  date为时间戳；

  var date = new Date(time);

  var Y = date.getFullYear() + "年";
  var M = (date.getMonth() + 1 < 10 ? "0" + (date.getMonth() + 1) : date.getMonth() + 1) + "月";
  var D = (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + "日 ";
  var h = (date.getHours() < 10 ? "0" + date.getHours() : date.getHours()) + ":";
  var m = (date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes()) + ":";
  var s = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
  return Y + M + D + h + m + s;
}